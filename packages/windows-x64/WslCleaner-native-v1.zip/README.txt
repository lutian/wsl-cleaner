WSL Cleaner native Windows application

Portable: double-click WslCleaner.exe. Close hides to tray; use Exit to quit.
Install: double-click Install.cmd (per user, no administrator required).
Optional startup: run Install.cmd -EnableStartup during first installation.
Uninstall: PowerShell -ExecutionPolicy Bypass -File Uninstall.ps1 in the installed folder.

No extra runtime installation is needed. Maintenance is opt-in. Budgets are advisory.
Do not run compaction until you understand its all-WSL/Docker shutdown and backup requirements.
Compaction requires explicit administrator launch and a backup on another fixed volume.
Ordinary stopped containers and volumes are not automatically deleted.
No guaranteed amount of recovered disk space is promised.

Extract this archive into a local Windows directory before installation.
Do not run the installer from a network/WSL UNC path. Existing installs are never overwritten.
Settings and backups are preserved during uninstall. See the source repository for details:
https://github.com/lutian/wsl-cleaner
