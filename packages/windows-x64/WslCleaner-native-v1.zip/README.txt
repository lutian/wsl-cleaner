﻿WSL Cleaner — aplicativo nativo para Windows

Sem instalar: abra WslCleaner.exe. Fechar no X oculta na bandeja; use Sair para encerrar.
Para instalar: abra Install.cmd (instalação por usuário, sem exigir administrador).
Inicialização opcional: execute Install.cmd -EnableStartup na primeira instalação.
Para desinstalar: PowerShell -ExecutionPolicy Bypass -File Uninstall.ps1 na pasta instalada.

Extraia o ZIP em uma pasta local do Windows. Não execute o instalador por um caminho
UNC de rede ou do WSL. Uma instalação existente nunca é sobrescrita automaticamente.
Para atualizar, saia do aplicativo, desinstale a versão anterior e instale a nova.
Configurações, backups e arquivos desconhecidos são preservados na desinstalação.

Aba Discos: escolha o disco, confira o caminho completo e salve somente seu limite de alerta.
Aba Configurações gerais: salve separadamente os intervalos, percentuais e opções globais.
Aba Manutenção: prepare e revise um plano antes de confirmar qualquer operação.
Aba Diagnóstico: detalhes técnicos e caminhos candidatos indisponíveis, não discos extras confirmados.

Não é necessário instalar runtime adicional. Os limites são alertas, não cotas rígidas.
A limpeza automática vem desligada. Containers comuns e volumes não são apagados automaticamente.
Compactar exige abrir explicitamente como administrador, autorizar a parada de todo o WSL/Docker
e ter backup verificado em outro volume fixo. Não interrompa a operação nem reinicie os serviços.
Não há promessa de tamanho final mínimo ou de quantidade de espaço recuperado.

O README completo, em português, explica cada controle e as proteções:
https://github.com/lutian/wsl-cleaner
