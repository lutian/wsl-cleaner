@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" -ExecutablePath "%~dp0WslCleaner.exe" %*
if errorlevel 1 pause
